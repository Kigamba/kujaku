package io.ona.kujaku.callables;

import java.util.concurrent.Callable;

/**
 * Created by Ephraim Kigamba - ekigamba@ona.io on 28/08/2018
 */

public interface AsyncTaskCallable extends Callable<Object[]> {
}
