package io.ona.kujaku.callbacks;

/**
 * @author Vincent Karuri
 */
public interface OnLocationComponentInitializedCallback {
    void  onLocationComponentInitialized();
}
