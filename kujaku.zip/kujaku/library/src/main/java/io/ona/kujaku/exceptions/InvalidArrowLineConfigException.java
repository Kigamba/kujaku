package io.ona.kujaku.exceptions;

/**
 * Created by Ephraim Kigamba - ekigamba@ona.io on 11/02/2019
 */

public class InvalidArrowLineConfigException extends Exception {

    public InvalidArrowLineConfigException(String message) {
        super(message);
    }
}
