package io.ona.kujaku.callbacks;

/**
 * @author Vincent Karuri
 */
public interface OnLocationServicesEnabledCallBack {
    void onSuccess();
}
