package io.ona.kujaku.listeners;

import android.location.Location;

/**
 * Created by Ephraim Kigamba - ekigamba@ona.io on 26/09/2018
 */

public interface OnLocationChanged {

    void onLocationChanged(Location location);
}
