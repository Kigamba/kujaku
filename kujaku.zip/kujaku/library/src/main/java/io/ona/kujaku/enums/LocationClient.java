package io.ona.kujaku.enums;

/**
 * Created by Ephraim Kigamba - ekigamba@ona.io on 2019-11-22
 */

public enum LocationClient {
    android_gps_client,
    google_location_client
}
