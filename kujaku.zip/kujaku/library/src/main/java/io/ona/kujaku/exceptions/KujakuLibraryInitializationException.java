package io.ona.kujaku.exceptions;

/**
 * @author Vincent Karuri
 */
public class KujakuLibraryInitializationException extends RuntimeException {
    public KujakuLibraryInitializationException(String message) {
        super(message);
    }
}
