package io.ona.kujaku.sample.util;

/**
 * @author Vincent Karuri
 */
public abstract class Constants {
    public static final String INSERT_OR_REPLACE = "INSERT OR REPLACE INTO %s VALUES ";
    public static final String DATABASE_NAME = "kujaku.db";
}